# Portafolio — Josué Jiménez Villarreal

Sitio de una sola página construido en HTML/CSS/JS puro (sin frameworks ni build step), pensado para desplegarse directo con GitHub Pages.

**Sitio en vivo:** `https://TU-USUARIO.github.io/` (o `https://TU-USUARIO.github.io/NOMBRE-DEL-REPO/`, según cómo nombres el repositorio — ver instrucciones abajo).

## Estructura

```
.
├── index.html          → la página completa (HTML + CSS + JS en un solo archivo)
├── images/              → aquí van tus fotos/renders de proyectos
│   ├── proyecto-1.jpg   → Optimización de Estructuras Aeronáuticas
│   ├── proyecto-2.jpg   → Diseño y Fabricación de Laminados Compuestos
│   ├── proyecto-3.jpg   → Prototipado y Validación de Ensambles
│   └── proyecto-4.jpg   → Caracterización de Elastómeros Magnetorreológicos
└── README.md
```

## Cómo reemplazar las imágenes placeholder

1. Agrega tus 4 imágenes a la carpeta `images/` con esos nombres exactos (o cambia el nombre en el código si prefieres otro).
2. Abre `index.html`, busca el comentario arriba de cada `<div class="img-placeholder">` (uno por proyecto) y sigue la instrucción: cambia ese `div` por un `<img class="project-img" src="images/proyecto-N.jpg" alt="...">`.
3. Proporción recomendada: 16:10 (ej. 1600×1000 px), para que se vean consistentes en la cuadrícula.

## Cómo editar contenido

Todo el texto (proyectos, experiencia, educación, contacto) está directamente en `index.html`, en español simple — no necesitas herramientas especiales, cualquier editor de texto funciona.

## Stack

- HTML5 + CSS3 (variables CSS, grid/flexbox) + JavaScript vanilla (solo para resaltar la sección activa al hacer scroll)
- Tipografía: IBM Plex Sans / IBM Plex Mono vía Google Fonts (HTTPS)
- Sin backend, sin dependencias de build, sin formularios — 100% estático
